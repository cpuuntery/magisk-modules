#!/system/bin/sh
# check env
if [ $BOOTMODE = true ]; then
ROOT=$(find `magisk --path` -type d -name "mirror" | head -n 1)
ui_print "- Root path: $ROOT"
else
ROOT=""
fi
# Fake mounting
PATH=/system/etc/permissions
ui_print "mkdir for the fake mount"
mkdir -p $MODPATH/system/etc/permissions
mv -f $MODPATH/platform.xml $MODPATH/system/etc/permissions
